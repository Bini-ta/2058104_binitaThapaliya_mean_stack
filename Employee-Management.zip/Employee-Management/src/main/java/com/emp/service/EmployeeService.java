package com.emp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.dto.EmployeeDao;
import com.emp.entity.Employee;
import com.emp.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDao employeeDao;
	
@Autowired
private EmployeeRepository employeeRepository;


	public List<Employee> getEmployees() {
		return employeeDao.findAll();
	}
@Transactional
	public void addEmployee(Employee employee) {
		employeeDao.save(employee);
	}

@Transactional
public void deleteEmployee(int id) {
	employeeDao.deleteEmployee(id);
}
@Transactional
public void updateEmployee(Employee employee) {
	employeeDao.updateEmployee(employee);
}
}