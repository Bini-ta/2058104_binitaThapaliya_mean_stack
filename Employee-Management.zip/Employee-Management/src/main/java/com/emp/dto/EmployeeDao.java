package com.emp.dto;

import java.util.List;

import javax.persistence.EntityManager;


import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.emp.entity.Employee;

@Repository
public class EmployeeDao {
	
	@Autowired
	EntityManager manager;
	
	
	public void save(Employee employee) {
		Session session = manager.unwrap(Session.class);
		session.save(employee);
	}
	public List<Employee> findAll() {
		// create a session
		Session session = manager.unwrap(Session.class);

		// create a query
		Query<Employee> query = session.createQuery("from Employee", Employee.class);

		// execute the query
		List<Employee> employees = query.getResultList();

		// return the result
		return employees;
	}

	public void deleteEmployee(int id) {
		Session session = manager.unwrap(Session.class);

		Employee employee = session.get(Employee.class, id);

		session.delete(employee);

	}
public void updateEmployee(Employee employee) {
	 Session session =manager.unwrap(Session.class);
     session.saveOrUpdate(employee);
}
	

}
